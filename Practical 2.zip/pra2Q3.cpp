﻿#include <iostream>
using namespace std;
int main()
{
	int a;
	cout<<"enter value of a ";
	cin>>a;
	int b;
	cout<<"enter value of b ";
		cin>>b;
	int c;
	cout<<"enter value of c ";
		cin>>c;
	int x;x=a/b-c;
	cout<<"in case 1 value of x ="<<x<<endl;

	
return 0;
	
}
