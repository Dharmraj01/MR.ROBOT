﻿#include<iostream>
using namespace std;
int main()
{
	int a,b;
	cout<<"enter frist number";
	cin>>a;
	cout<<"enter sec number";
    cin>>b;
    	cout<<"\t addision of a and b is "<<a+b<<"\n";
	cout<<"enter frist number";
	cin>>a;
	cout<<"enter sec number";
    cin>>b;
    	cout<<"\tsub of a and b is "<<a-b<<"\n";
	cout<<"enter frist number";
	cin>>a;
	cout<<"enter sec number";
    cin>>b;
    	cout<<"\t mul of a and b is "<<a*b<<"\n";
	cout<<"enter frist number";
	cin>>a;
	cout<<"enter sec number";
    cin>>b;
	cout<<"\t div of a and b is "<<a/b<<"\n";
	
	
}
