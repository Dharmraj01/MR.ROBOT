﻿#include <iostream>
using namespace std;
int main()
{
	cout<<"maths=90"<<"\nphysics=77"<<"\nchemistry=69";
	
	return 0;
}
