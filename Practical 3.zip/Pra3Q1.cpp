﻿#include <iostream>
using namespace std;
int a;
int main(){
	int b;
	cout<<"Enter 1 value :";
	cin>>::a;
	cout<<"Enter 2 value :";
	cin>>b;
	cout<<"addition of 2 number is "<<a+b<<"\n";
	cout<<"subtraction of 2 number is "<<a-b<<"\n";
	return 0;
	}
	
