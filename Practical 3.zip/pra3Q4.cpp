﻿#include <iostream>
#include <iomanip>
using namespace std;
int main(){
	cout<<setfill('#')<<setw(13)<<"ILikeC++";
	return 0;
	}
