﻿#include <iostream>
using namespace std;
int a,b;
int main(){
	int c;
	cout<<"enter 1 value :";
	cin>>::a;
	cout<<"enter 2 value :";
	cin>>::b;
	cout<<"enter 3 value :";
	cin>>c;
	if(::a>::b && ::a>c)
	  {
	  	cout<<::a<<" is greater than "<<::b<<"and"<<c<<"\n";
	  	}
	  	else if(::b>::a && ::b>c) {
	  		cout<<::b<<" is greater than "<<::a<<"and"<<c<<"\n";
	  		}
	  		else{
	  			cout<<c<<" is greater than "<<::a<<" and "<<::b<<"\n";
	  			}
	return 0;
	  			}
	
