﻿#include <iostream>
using namespace std;
int main(){
	cout<<"Hello hi"<<endl<<"How"<<endl<<"are"<<endl<<"you?"<<endl<<"I am"<<endl<<"Fine";
	return 0;
	}
